export const contactData = [
    {
      title: "Truck Related Queries",
      description: "GPS, FASTag & more",
      phone: "9266339683",
      email: "enterprisesolutions@FarmXpress.com",
    },
    {
      title: "Load Related Queries",
      description: "Get instant quotes",
      phone: "9370093700",
      email: "support@FarmXpress.com",
    },
    {
      title: "Call Our Helpline",
      description: "24x7 customer support",
      phone: "9370093700",
      email: "care@FarmXpress.com",
    },
  ];